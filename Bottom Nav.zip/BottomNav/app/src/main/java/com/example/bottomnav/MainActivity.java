package com.example.bottomnav;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    public DrawerLayout drawerLayout;
    public NavigationView navigationView;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    private FloatingActionButton floatingActionButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initialise();
        itemClickListener();
        change_Activity(new Home());

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Create Clicked!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void itemClickListener() {
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.home1:
                        Toast.makeText(MainActivity.this, "Home", Toast.LENGTH_SHORT).show();
                        bottomNavigationView.getMenu().findItem(R.id.home).setChecked(true);
                        change_Activity(new Home());
                        break;
                    case R.id.explore1:
                        Toast.makeText(MainActivity.this, "Explore", Toast.LENGTH_SHORT).show();
                        bottomNavigationView.getMenu().findItem(R.id.explore).setChecked(true);
                        change_Activity(new Explore());
                        break;
                    case R.id.profile1:
                        Toast.makeText(MainActivity.this, "Profile", Toast.LENGTH_SHORT).show();
                        bottomNavigationView.getMenu().findItem(R.id.profile).setChecked(true);
                        change_Activity(new Profile());
                        break;
                    case R.id.settings1:
                        Toast.makeText(MainActivity.this, "Settings", Toast.LENGTH_SHORT).show();
                        bottomNavigationView.getMenu().findItem(R.id.settings).setChecked(true);
                        change_Activity(new Settings());
                        break;
                    case R.id.logout1:
                        Toast.makeText(MainActivity.this, "Logout", Toast.LENGTH_SHORT).show();
                        break;
                }
                drawerLayout.closeDrawer(GravityCompat.START);
                return false;
            }
        });
        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.home :
                    change_Activity(new Home());
                    break;
                case R.id.explore:
                    change_Activity(new Explore());
                    break;
                case R.id.profile :
                    change_Activity(new Profile());
                    break;
                case R.id.settings:
                    change_Activity(new Settings());
                    break;
            }
            return true;
        });
    }

    private void initialise() {
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomnavigationbar);
        drawerLayout = (DrawerLayout) findViewById(R.id.my_drawer_layout);
        navigationView = (NavigationView) findViewById(R.id.navigation);
        floatingActionButton = (FloatingActionButton) findViewById(R.id.fab);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);
        bottomNavigationView.setBackground(null);
        bottomNavigationView.getMenu().getItem(2).setEnabled(false);
        bottomNavigationView.getMenu().findItem(R.id.home).setChecked(true);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }

    private void change_Activity(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_dash,fragment);
        fragmentTransaction.commit();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}